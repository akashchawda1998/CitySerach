import java.io.IOException;
import java.io.InputStream;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
 
@WebServlet("/Servlet")
@MultipartConfig(maxFileSize = 16177215)    // upload file's size up to 16MB
public class FileUploadDBServlet extends HttpServlet {     
    @Override
    protected void doPost(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException {
       String city=request.getParameter("city");
   String category=request.getParameter("category");
   String description=request.getParameter("description");
   String address=request.getParameter("address");  
        Part filePart = request.getPart("photo");
        if (filePart != null) {
        InputStream   inputStream = filePart.getInputStream();
        
        try {
            DriverManager.registerDriver(new com.mysql.jdbc.Driver());
           Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/citysearch","root","root");
            String sql = "insert into city_details(city,category,description,address,photo)values (?,?,?,?,?)";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setString(1, city);
             statement.setString(2, category);
             statement.setString(3, description);
             statement.setString(4, address); 
             statement.setBlob(5, inputStream);
             int row = statement.executeUpdate();
             RequestDispatcher rs= request.getRequestDispatcher("/admin_main.jsp");
             rs.forward(request, response);
        } catch (SQLException ex) {
           out.print("error");
        } 
    }
}}